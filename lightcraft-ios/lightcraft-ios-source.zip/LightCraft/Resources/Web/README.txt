The build workflow replaces this placeholder with the official LightCraft
WebAssembly release before generating the Xcode project.
