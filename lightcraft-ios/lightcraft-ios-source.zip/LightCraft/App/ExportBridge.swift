import Foundation
import Photos
import UIKit
import WebKit

/// Receives files from the LightCraft parent bridge in bounded chunks.
///
/// The web application normally turns exports into browser downloads. Inside
/// WKWebView those downloads are inconsistent, so the wrapper page listens for
/// `lightcraft:save`, converts the transferred bytes to base64 chunks, and this
/// native handler writes them to Documents. Image exports are also added to the
/// Photos library.
final class ExportBridge: NSObject, WKScriptMessageHandler {
    weak var presenter: UIViewController?

    private struct Session {
        let name: String
        let url: URL
        let handle: FileHandle
        let expectedSize: Int64
        var written: Int64
    }

    private var sessions: [String: Session] = [:]

    init(presenter: UIViewController?) {
        self.presenter = presenter
    }

    func userContentController(
        _ userContentController: WKUserContentController,
        didReceive message: WKScriptMessage
    ) {
        guard message.name == "lightcraftSave",
              let body = message.body as? [String: Any],
              let action = body["action"] as? String else {
            return
        }
        switch action {
        case "begin":
            begin(body)
        case "chunk":
            append(body)
        case "end":
            finish(body)
        case "abort":
            abort(body)
        default:
            break
        }
    }

    private func begin(_ body: [String: Any]) {
        guard let id = body["id"] as? String else { return }
        let suppliedName = (body["name"] as? String) ?? "LightCraft-export"
        let size = (body["size"] as? NSNumber)?.int64Value ?? 0
        do {
            let directory = try exportsDirectory()
            let name = uniqueName(sanitized(suppliedName), in: directory)
            let url = directory.appendingPathComponent(name)
            guard FileManager.default.createFile(atPath: url.path, contents: nil) else {
                throw ExportBridgeError.cannotCreateFile
            }
            let handle = try FileHandle(forWritingTo: url)
            sessions[id] = Session(
                name: name,
                url: url,
                handle: handle,
                expectedSize: size,
                written: 0
            )
        } catch {
            presentError(error.localizedDescription)
        }
    }

    private func append(_ body: [String: Any]) {
        guard let id = body["id"] as? String,
              let text = body["base64"] as? String,
              let data = Data(base64Encoded: text, options: .ignoreUnknownCharacters),
              var session = sessions[id] else {
            return
        }
        do {
            try session.handle.write(contentsOf: data)
            session.written += Int64(data.count)
            sessions[id] = session
        } catch {
            try? session.handle.close()
            sessions.removeValue(forKey: id)
            try? FileManager.default.removeItem(at: session.url)
            presentError("写入导出文件失败：\(error.localizedDescription)")
        }
    }

    private func finish(_ body: [String: Any]) {
        guard let id = body["id"] as? String,
              let session = sessions.removeValue(forKey: id) else {
            return
        }
        try? session.handle.close()
        if session.expectedSize > 0 && session.written != session.expectedSize {
            try? FileManager.default.removeItem(at: session.url)
            presentError("导出文件不完整，请重试")
            return
        }
        saveToPhotosIfSupported(session.url)
    }

    private func abort(_ body: [String: Any]) {
        guard let id = body["id"] as? String,
              let session = sessions.removeValue(forKey: id) else {
            return
        }
        try? session.handle.close()
        try? FileManager.default.removeItem(at: session.url)
        if let error = body["error"] as? String {
            presentError("导出失败：\(error)")
        }
    }

    private func exportsDirectory() throws -> URL {
        let documents = FileManager.default.urls(
            for: .documentDirectory,
            in: .userDomainMask
        )[0]
        let directory = documents.appendingPathComponent("LightCraft Exports", isDirectory: true)
        try FileManager.default.createDirectory(
            at: directory,
            withIntermediateDirectories: true
        )
        return directory
    }

    private func sanitized(_ name: String) -> String {
        var candidate = URL(fileURLWithPath: name).lastPathComponent
            .replacingOccurrences(of: "/", with: "-")
            .replacingOccurrences(of: ":", with: "-")
        candidate = candidate.trimmingCharacters(in: .whitespacesAndNewlines)
        if candidate.isEmpty || candidate == "." || candidate == ".." {
            candidate = "LightCraft-export"
        }
        return candidate
    }

    private func uniqueName(_ name: String, in directory: URL) -> String {
        var candidate = name
        let stem = (name as NSString).deletingPathExtension
        let ext = (name as NSString).pathExtension
        var counter = 2
        while FileManager.default.fileExists(
            atPath: directory.appendingPathComponent(candidate).path
        ) {
            candidate = ext.isEmpty ? "\(stem)-\(counter)" : "\(stem)-\(counter).\(ext)"
            counter += 1
        }
        return candidate
    }

    private func saveToPhotosIfSupported(_ url: URL) {
        let ext = url.pathExtension.lowercased()
        let imageExtensions: Set<String> = [
            "jpg", "jpeg", "png", "tif", "tiff", "heic", "heif",
        ]
        guard imageExtensions.contains(ext) else {
            presentSavedMessage("文件已保存到“文件”App：LightCraft Exports/\(url.lastPathComponent)")
            return
        }
        PHPhotoLibrary.requestAuthorization(for: .addOnly) { [weak self] status in
            guard status == .authorized || status == .limited else {
                self?.presentSavedMessage(
                    "文件已保存到“文件”App；相册权限未开启，未写入相册。"
                )
                return
            }
            PHPhotoLibrary.shared().performChanges {
                PHAssetCreationRequest.forAsset()
                    .addResource(with: .photo, fileURL: url, options: nil)
            } completionHandler: { success, error in
                if success {
                    self?.presentSavedMessage(
                        "已保存到相册，同时保留在“文件”App：LightCraft Exports/\(url.lastPathComponent)"
                    )
                } else {
                    self?.presentSavedMessage(
                        "文件已保存到“文件”App；写入相册失败：\(error?.localizedDescription ?? "未知错误")"
                    )
                }
            }
        }
    }

    private func presentSavedMessage(_ text: String) {
        DispatchQueue.main.async { [weak self] in
            let alert = UIAlertController(
                title: "LightCraft 导出完成",
                message: text,
                preferredStyle: .alert
            )
            alert.addAction(UIAlertAction(title: "好", style: .default))
            self?.presenter?.present(alert, animated: true)
        }
    }

    private func presentError(_ text: String) {
        DispatchQueue.main.async { [weak self] in
            let alert = UIAlertController(
                title: "LightCraft 导出失败",
                message: text,
                preferredStyle: .alert
            )
            alert.addAction(UIAlertAction(title: "好", style: .default))
            self?.presenter?.present(alert, animated: true)
        }
    }
}

private enum ExportBridgeError: LocalizedError {
    case cannotCreateFile

    var errorDescription: String? {
        "无法在 LightCraft Exports 中创建导出文件"
    }
}
