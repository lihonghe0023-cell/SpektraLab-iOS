import Foundation
import Network

/// A deliberately small loopback HTTP server.
///
/// LightCraft's WebAssembly bundle cannot run from `file://`: module workers and
/// persistent browser storage need an HTTP(S) origin. Binding a fixed loopback
/// port also keeps the browser storage origin stable between application launches,
/// so the imported photo library survives a restart.
final class LocalWebServer {
    static let port: UInt16 = 18787

    private let resourceRoot: URL
    private let queue = DispatchQueue(label: "com.hanze.lightcraft.http")
    private var listener: NWListener?

    private var wrapperRoot: URL {
        resourceRoot.appendingPathComponent("Wrapper", isDirectory: true)
    }

    private var webRoot: URL {
        resourceRoot.appendingPathComponent("Web", isDirectory: true)
    }

    init(resourceRoot: URL) {
        self.resourceRoot = resourceRoot
    }

    func start(completion: @escaping (Result<URL, Error>) -> Void) {
        guard listener == nil else {
            completion(.failure(ServerError.alreadyRunning))
            return
        }
        guard let port = NWEndpoint.Port(rawValue: Self.port),
              FileManager.default.fileExists(
                atPath: wrapperRoot.appendingPathComponent("index.html").path
              ),
              FileManager.default.fileExists(
                atPath: webRoot.appendingPathComponent("index.html").path
              ) else {
            completion(.failure(ServerError.bundleIncomplete))
            return
        }

        do {
            let parameters = NWParameters.tcp
            parameters.allowLocalEndpointReuse = true
            parameters.requiredInterfaceType = .loopback
            let listener = try NWListener(using: parameters, on: port)
            var completed = false
            let finish: (Result<URL, Error>) -> Void = { result in
                guard !completed else { return }
                completed = true
                if case .failure = result {
                    listener.cancel()
                }
                completion(result)
            }
            listener.stateUpdateHandler = { state in
                switch state {
                case .ready:
                    guard let url = URL(string: "http://127.0.0.1:\(Self.port)/") else {
                        finish(.failure(ServerError.invalidURL))
                        return
                    }
                    finish(.success(url))
                case .failed(let error):
                    finish(.failure(error))
                case .cancelled:
                    finish(.failure(ServerError.cancelled))
                default:
                    break
                }
            }
            listener.newConnectionHandler = { [weak self] connection in
                self?.accept(connection)
            }
            self.listener = listener
            listener.start(queue: queue)
        } catch {
            completion(.failure(error))
        }
    }

    func stop() {
        listener?.cancel()
        listener = nil
    }

    private func accept(_ connection: NWConnection) {
        connection.start(queue: queue)
        receiveRequest(on: connection, buffer: Data())
    }

    private func receiveRequest(on connection: NWConnection, buffer: Data) {
        connection.receive(
            minimumIncompleteLength: 1,
            maximumLength: 64 * 1024
        ) { [weak self] data, _, isComplete, error in
            guard let self else {
                connection.cancel()
                return
            }
            var accumulated = buffer
            if let data {
                accumulated.append(data)
            }
            guard accumulated.count <= 128 * 1024 else {
                self.respond(connection, status: 431, body: Data(), type: "text/plain")
                return
            }
            if let separator = accumulated.range(of: Data("\r\n\r\n".utf8)) {
                let header = accumulated.subdata(in: 0..<separator.lowerBound)
                self.handle(header: header, connection: connection)
            } else if isComplete || error != nil {
                connection.cancel()
            } else {
                self.receiveRequest(on: connection, buffer: accumulated)
            }
        }
    }

    private func handle(header: Data, connection: NWConnection) {
        guard let text = String(data: header, encoding: .utf8) else {
            respond(connection, status: 400, body: Data(), type: "text/plain")
            return
        }
        let lines = text.components(separatedBy: "\r\n")
        guard let requestLine = lines.first else {
            respond(connection, status: 400, body: Data(), type: "text/plain")
            return
        }
        let parts = requestLine.split(separator: " ", maxSplits: 2).map(String.init)
        guard parts.count >= 2 else {
            respond(connection, status: 400, body: Data(), type: "text/plain")
            return
        }
        let method = parts[0].uppercased()
        guard method == "GET" || method == "HEAD" else {
            respond(connection, status: 405, body: Data(), type: "text/plain")
            return
        }

        let requestTarget = parts[1]
        let path = URLComponents(string: requestTarget)?.path ?? requestTarget
        guard let fileURL = resolve(path: path) else {
            respond(connection, status: 404, body: Data("Not found".utf8), type: "text/plain")
            return
        }
        guard let data = try? Data(contentsOf: fileURL, options: [.mappedIfSafe]) else {
            respond(connection, status: 404, body: Data("Not found".utf8), type: "text/plain")
            return
        }

        let rangeHeader = lines.first {
            $0.lowercased().hasPrefix("range:")
        }
        let contentType = mimeType(for: fileURL.pathExtension)
        respond(
            connection,
            status: 200,
            body: data,
            type: contentType,
            method: method,
            rangeHeader: rangeHeader
        )
    }

    private func resolve(path: String) -> URL? {
        let decoded = path.removingPercentEncoding ?? path
        let relative = decoded.hasPrefix("/") ? String(decoded.dropFirst()) : decoded
        let base: URL
        let rel: String
        if decoded == "/" || decoded.isEmpty {
            base = wrapperRoot
            rel = "index.html"
        } else if relative == "app" || relative.hasPrefix("app/") {
            base = webRoot
            rel = relative == "app" ? "index.html" : String(relative.dropFirst(4))
        } else {
            base = wrapperRoot
            rel = relative
        }
        guard !rel.split(separator: "/").contains("..") else { return nil }

        var candidate = base.appendingPathComponent(rel).standardizedFileURL
        var isDirectory: ObjCBool = false
        guard FileManager.default.fileExists(atPath: candidate.path, isDirectory: &isDirectory) else {
            return nil
        }
        if isDirectory.boolValue {
            candidate.appendPathComponent("index.html")
        }
        let root = base.standardizedFileURL.path
        let resolved = candidate.standardizedFileURL.path
        guard resolved == root || resolved.hasPrefix(root + "/") else { return nil }
        return candidate
    }

    private func respond(
        _ connection: NWConnection,
        status: Int,
        body: Data,
        type: String,
        method: String = "GET",
        rangeHeader: String? = nil
    ) {
        var responseBody = body
        var responseStatus = status
        var contentRange: String?

        if status == 200,
           let range = parseRange(rangeHeader, total: body.count) {
            responseStatus = 206
            responseBody = body.subdata(in: range)
            contentRange = "bytes \(range.lowerBound)-\(range.upperBound - 1)/\(body.count)"
        }

        var headers = [
            "HTTP/1.1 \(responseStatus) \(reason(responseStatus))",
            "Content-Type: \(type)",
            "Content-Length: \(responseBody.count)",
            "Accept-Ranges: bytes",
            "Cache-Control: no-cache",
            "Cross-Origin-Opener-Policy: same-origin",
            "Cross-Origin-Embedder-Policy: require-corp",
            "Cross-Origin-Resource-Policy: same-origin",
            "Connection: close",
        ]
        if let contentRange {
            headers.append("Content-Range: \(contentRange)")
        }
        let responseHeader = Data((headers.joined(separator: "\r\n") + "\r\n\r\n").utf8)

        connection.send(content: responseHeader, isComplete: false, completion: .contentProcessed { _ in
            if method == "HEAD" {
                connection.cancel()
                return
            }
            connection.send(content: responseBody, isComplete: true, completion: .contentProcessed { _ in
                connection.cancel()
            })
        })
    }

    private func parseRange(_ text: String?, total: Int) -> Range<Int>? {
        guard let text,
              let value = text.split(separator: ":", maxSplits: 1).last?
                .trimmingCharacters(in: .whitespaces),
              value.hasPrefix("bytes="),
              !value.contains(",") else {
            return nil
        }
        let range = value.dropFirst(6).split(separator: "-", maxSplits: 1)
        guard range.count == 2 else { return nil }
        let startText = String(range[0]).trimmingCharacters(in: .whitespaces)
        let endText = String(range[1]).trimmingCharacters(in: .whitespaces)
        let start = Int(startText) ?? 0
        let end = endText.isEmpty ? total : (Int(endText).map { $0 + 1 } ?? total)
        guard start >= 0, start < total else { return nil }
        return start..<min(total, max(start + 1, end))
    }

    private func mimeType(for extensionName: String) -> String {
        switch extensionName.lowercased() {
        case "html": return "text/html; charset=utf-8"
        case "js", "mjs": return "application/javascript; charset=utf-8"
        case "wasm": return "application/wasm"
        case "json": return "application/json; charset=utf-8"
        case "css": return "text/css; charset=utf-8"
        case "otf": return "font/otf"
        case "ttf": return "font/ttf"
        case "svg": return "image/svg+xml"
        case "png": return "image/png"
        case "jpg", "jpeg": return "image/jpeg"
        case "webp": return "image/webp"
        case "tif", "tiff": return "image/tiff"
        case "zip": return "application/zip"
        default: return "application/octet-stream"
        }
    }

    private func reason(_ status: Int) -> String {
        switch status {
        case 200: return "OK"
        case 206: return "Partial Content"
        case 400: return "Bad Request"
        case 404: return "Not Found"
        case 405: return "Method Not Allowed"
        case 431: return "Request Header Fields Too Large"
        default: return "Error"
        }
    }
}

private enum ServerError: LocalizedError {
    case alreadyRunning
    case bundleIncomplete
    case invalidURL
    case cancelled

    var errorDescription: String? {
        switch self {
        case .alreadyRunning: return "本地服务器已经启动"
        case .bundleIncomplete: return "安装包缺少 LightCraft 网页资源"
        case .invalidURL: return "无法建立本地网页地址"
        case .cancelled: return "本地服务器已停止"
        }
    }
}
