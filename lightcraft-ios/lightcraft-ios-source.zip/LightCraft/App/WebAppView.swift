import SwiftUI
import UIKit
import WebKit

struct WebAppView: UIViewControllerRepresentable {
    func makeUIViewController(context: Context) -> WebAppController {
        WebAppController()
    }

    func updateUIViewController(_ uiViewController: WebAppController, context: Context) {}
}

final class WebAppController: UIViewController {
    private let server: LocalWebServer
    private let webView: WKWebView
    private let statusBridge: LightCraftStatusBridge
    private let exportBridge: ExportBridge
    private let overlay = UIView()
    private let overlayLabel = UILabel()
    private let activity = UIActivityIndicatorView(style: .large)

    convenience init() {
        self.init(nibName: nil, bundle: nil)
    }

    override init(nibName nibNameOrNil: String?, bundle nibBundleOrNil: Bundle?) {
        let resources = Bundle.main.resourceURL!
        server = LocalWebServer(resourceRoot: resources)
        let configuration = WKWebViewConfiguration()
        configuration.websiteDataStore = .default()
        configuration.defaultWebpagePreferences.allowsContentJavaScript = true
        configuration.preferences.javaScriptCanOpenWindowsAutomatically = false
        webView = WKWebView(frame: .zero, configuration: configuration)
        statusBridge = LightCraftStatusBridge()
        exportBridge = ExportBridge(presenter: nil)
        super.init(nibName: nibNameOrNil, bundle: nibBundleOrNil)
        statusBridge.controller = self
        exportBridge.presenter = self
        configuration.userContentController.add(statusBridge, name: "lightcraftStatus")
        configuration.userContentController.add(exportBridge, name: "lightcraftSave")
    }

    @available(*, unavailable)
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }

    override var preferredStatusBarStyle: UIStatusBarStyle {
        .lightContent
    }

    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = UIColor(red: 0.11, green: 0.11, blue: 0.11, alpha: 1)
        webView.translatesAutoresizingMaskIntoConstraints = false
        webView.navigationDelegate = self
        webView.uiDelegate = self
        webView.isOpaque = false
        webView.backgroundColor = view.backgroundColor
        webView.scrollView.backgroundColor = view.backgroundColor
        webView.scrollView.contentInsetAdjustmentBehavior = .never
        webView.scrollView.bounces = false
        view.addSubview(webView)
        NSLayoutConstraint.activate([
            webView.leadingAnchor.constraint(equalTo: view.leadingAnchor),
            webView.trailingAnchor.constraint(equalTo: view.trailingAnchor),
            webView.topAnchor.constraint(equalTo: view.topAnchor),
            webView.bottomAnchor.constraint(equalTo: view.bottomAnchor),
        ])
        installOverlay()
        start()
    }

    deinit {
        webView.configuration.userContentController.removeScriptMessageHandler(
            forName: "lightcraftStatus"
        )
        webView.configuration.userContentController.removeScriptMessageHandler(
            forName: "lightcraftSave"
        )
        server.stop()
    }

    private func installOverlay() {
        overlay.translatesAutoresizingMaskIntoConstraints = false
        overlay.backgroundColor = view.backgroundColor
        overlayLabel.translatesAutoresizingMaskIntoConstraints = false
        overlayLabel.textColor = .secondaryLabel
        overlayLabel.font = .systemFont(ofSize: 16, weight: .medium)
        overlayLabel.textAlignment = .center
        overlayLabel.numberOfLines = 0
        overlayLabel.text = "正在启动 LightCraft…"
        activity.translatesAutoresizingMaskIntoConstraints = false
        activity.color = .secondaryLabel
        overlay.addSubview(overlayLabel)
        overlay.addSubview(activity)
        view.addSubview(overlay)
        NSLayoutConstraint.activate([
            overlay.leadingAnchor.constraint(equalTo: view.leadingAnchor),
            overlay.trailingAnchor.constraint(equalTo: view.trailingAnchor),
            overlay.topAnchor.constraint(equalTo: view.topAnchor),
            overlay.bottomAnchor.constraint(equalTo: view.bottomAnchor),
            activity.centerXAnchor.constraint(equalTo: overlay.centerXAnchor),
            activity.centerYAnchor.constraint(equalTo: overlay.centerYAnchor, constant: -30),
            overlayLabel.leadingAnchor.constraint(equalTo: overlay.leadingAnchor, constant: 32),
            overlayLabel.trailingAnchor.constraint(equalTo: overlay.trailingAnchor, constant: -32),
            overlayLabel.topAnchor.constraint(equalTo: activity.bottomAnchor, constant: 18),
        ])
        activity.startAnimating()
    }

    private func start() {
        server.start { [weak self] result in
            DispatchQueue.main.async {
                guard let self else { return }
                switch result {
                case .success(let url):
                    self.webView.load(URLRequest(url: url))
                case .failure(let error):
                    self.showStartupError(error.localizedDescription)
                }
            }
        }
    }

    fileprivate func markReady(version: String) {
        UIView.animate(withDuration: 0.2) {
            self.overlay.alpha = 0
        } completion: { _ in
            self.overlay.isHidden = true
            self.activity.stopAnimating()
        }
        print("LightCraft web ready: \(version)")
    }

    fileprivate func showStartupError(_ text: String) {
        overlay.isHidden = false
        overlay.alpha = 1
        activity.stopAnimating()
        overlayLabel.text = "LightCraft 启动失败\n\n\(text)"
    }

    fileprivate func showAlert(title: String, message: String, completion: (() -> Void)? = nil) {
        let alert = UIAlertController(
            title: title,
            message: message,
            preferredStyle: .alert
        )
        alert.addAction(UIAlertAction(title: "好", style: .default) { _ in
            completion?()
        })
        present(alert, animated: true)
    }
}

extension WebAppController: WKNavigationDelegate {
    func webView(
        _ webView: WKWebView,
        didFail navigation: WKNavigation!,
        withError error: Error
    ) {
        showStartupError(error.localizedDescription)
    }

    func webView(
        _ webView: WKWebView,
        didFailProvisionalNavigation navigation: WKNavigation!,
        withError error: Error
    ) {
        showStartupError(error.localizedDescription)
    }
}

extension WebAppController: WKUIDelegate {
    func webView(
        _ webView: WKWebView,
        runJavaScriptAlertPanelWithMessage message: String,
        initiatedByFrame frame: WKFrameInfo,
        completionHandler: @escaping () -> Void
    ) {
        showAlert(title: "LightCraft", message: message, completion: completionHandler)
    }

    func webView(
        _ webView: WKWebView,
        runJavaScriptConfirmPanelWithMessage message: String,
        initiatedByFrame frame: WKFrameInfo,
        completionHandler: @escaping (Bool) -> Void
    ) {
        let alert = UIAlertController(
            title: "LightCraft",
            message: message,
            preferredStyle: .alert
        )
        alert.addAction(UIAlertAction(title: "取消", style: .cancel) { _ in
            completionHandler(false)
        })
        alert.addAction(UIAlertAction(title: "确定", style: .default) { _ in
            completionHandler(true)
        })
        present(alert, animated: true)
    }

    func webView(
        _ webView: WKWebView,
        runJavaScriptTextInputPanelWithPrompt prompt: String,
        defaultText: String?,
        initiatedByFrame frame: WKFrameInfo,
        completionHandler: @escaping (String?) -> Void
    ) {
        let alert = UIAlertController(title: "LightCraft", message: prompt, preferredStyle: .alert)
        alert.addTextField { field in
            field.text = defaultText
        }
        alert.addAction(UIAlertAction(title: "取消", style: .cancel) { _ in
            completionHandler(nil)
        })
        alert.addAction(UIAlertAction(title: "确定", style: .default) { _ in
            completionHandler(alert.textFields?.first?.text)
        })
        present(alert, animated: true)
    }
}

private final class LightCraftStatusBridge: NSObject, WKScriptMessageHandler {
    weak var controller: WebAppController?

    func userContentController(
        _ userContentController: WKUserContentController,
        didReceive message: WKScriptMessage
    ) {
        guard message.name == "lightcraftStatus",
              let body = message.body as? [String: Any],
              let type = body["type"] as? String else {
            return
        }
        switch type {
        case "ready":
            controller?.markReady(version: body["version"] as? String ?? "")
        case "failed":
            controller?.showStartupError(body["error"] as? String ?? "未知错误")
        default:
            break
        }
    }
}
