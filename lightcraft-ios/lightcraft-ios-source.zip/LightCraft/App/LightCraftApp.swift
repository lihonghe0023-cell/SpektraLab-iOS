import SwiftUI

@main
struct LightCraftApp: App {
    var body: some Scene {
        WindowGroup {
            WebAppView()
                .preferredColorScheme(.dark)
        }
    }
}
