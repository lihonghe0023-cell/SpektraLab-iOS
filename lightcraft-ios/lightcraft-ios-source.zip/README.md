# LightCraft iOS container

This is an unofficial iOS wrapper around the official LightCraft WebAssembly
build from [storytold/lightcraft](https://github.com/storytold/lightcraft).

The wrapper:

- serves the web build from a fixed loopback HTTP origin so Web Workers,
  WebAssembly, and persistent browser storage work inside WKWebView;
- keeps the origin stable between launches so the imported library survives;
- forwards LightCraft exports to native Swift;
- saves image exports to Photos and keeps every export in the app's Documents
  folder (`LightCraft Exports`), visible in the Files app;
- supplies the official LightCraft application icon and attribution files.

The web application and LightCraft icon remain under their upstream licenses.
See `LightCraft/Resources/LIGHTCRAFT-ICON-LICENSE.txt` and the license and
notice files copied from the official web release into
`LightCraft/Resources/Web/`.

LightCraft is Copyright (c) 2026 ArtCraft Team and the LightCraft contributors.
This wrapper is not published or endorsed by the upstream project.
